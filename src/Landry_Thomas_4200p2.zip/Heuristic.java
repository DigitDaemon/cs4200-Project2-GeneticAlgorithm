
public interface Heuristic {
	int operation(int[] t);
	
}
